import { @Vigilant, @SwitchProperty, @TextProperty, @CheckboxProperty, @ButtonProperty, @SelectorProperty, @SliderProperty, @ColorProperty, @PercentSliderProperty, Color} from "../Vigilance/index"

@Vigilant("PGS_Addons", "pgs", {
  getCategoryComparator: () => (a, b) => {
    const categories = ["General"]
    return categories.indexOf(a.name) - categories.indexOf(b.name);
  }
})
class Settings {  
  @SwitchProperty({
    name: "AutoFish",
    description: "MUST HAVE SOUND ON",
    category: "General"
  })
  autofish = true  
}
export default new Settings();