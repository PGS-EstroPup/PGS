import settings from "./config";
import RenderLib from "./../RenderLib"
import renderBeaconBeam from "BeaconBeam"

const comma = (num) => {
  if(num == undefined) return;
  return num.toString()?.replace(/\B(?=(\d{3})+(?!\d))/g, ',')
}

register("command", (args) => {  
  if (!args) {
    settings.openGUI()
  }
}).setCommandName(`pgs`, true).setAliases("pgsaddons")

let registers = [];
function registerWhen(trigger, dependency) {
  registers.push([trigger.unregister(), dependency, false]);
}

function setRegisters() {
  registers.forEach(trigger => {
    if (trigger[1]() && !trigger[2]) {
      trigger[0].register();
      trigger[2] = true;
    } else if (!trigger[1]() && trigger[2]) {
      trigger[0].unregister();
      trigger[2] = false;
    }
  });
}
setTimeout(() => {
  setRegisters()
}, 1000);

register("guiClosed", (event) => {
  if (!event.toString().includes("vigilance")) return
  settings.save()
  setRegisters()
});

let world = undefined;
export function getWorld() { return world; };
let noFind = 0;

export function findZone() {
  let zoneLine = Scoreboard.getLines().find((line) => line.getName().includes("⏣"));
  if (zoneLine == undefined) zoneLine = Scoreboard.getLines().find((line) => line.getName().includes("ф"));
  return zoneLine == undefined ? "None" : zoneLine.getName().removeFormatting()
}
function findWorld() {
  if (noFind == 20) return;
  noFind++;
  world = TabList.getNames().find(tab => tab.includes("Area"));
  if (world == undefined)
    setTimeout(() => {
      findWorld()
    }, 1000);
  else {
    world = world.removeFormatting();
    world = world.substring(world.indexOf(': ') + 2);

    setRegisters();
  }
}

register("worldLoad", () => {
  noFind = 0;
  findWorld()
});

let bm = 0
register("worldUnload", () => {
  world = undefined
  bm = 0
})

registerWhen(register("soundPlay", () => {
  let holding = Player.getHeldItem();
  if (holding == null || holding.getRegistryName() != "minecraft:fishing_rod" || !Client.isInGui) return
  World.getAllEntitiesOfType(Java.type("net.minecraft.entity.item.EntityArmorStand").class).forEach(stand => {
    if (stand.getName().includes("!!!")) {
      Client.getKeyBindFromDescription("key.use").setState(true)
      setTimeout(() => {
        Client.getKeyBindFromDescription("key.use").setState(false)
      }, 250);
    }
  })
}).setCriteria("note.pling"), () => settings.autofish)